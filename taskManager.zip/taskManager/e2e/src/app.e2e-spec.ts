import { AppPage } from './app.po';
import { browser, by, element } from 'protractor';

describe('workspace-project App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display Add Task and test the inputs fields and buttons', () => {
    //Navigate to add task page
    page.navigateTo();
    //Check if the input fields are availale
    expect(element(by.cssContainingText('app-add-task label','Task')).getText()).toEqual('Task');
    expect(element(by.cssContainingText('app-add-task label','Priority')).getText()).toEqual('Priority');
    expect(element(by.cssContainingText('app-add-task label','Parent Task')).getText()).toEqual('Parent Task');
    expect(element(by.cssContainingText('app-add-task label','Start Date')).getText()).toEqual('Start Date');
    expect(element(by.cssContainingText('app-add-task label','End Date')).getText()).toEqual('End Date');
    //send values to input fields
    expect(element(by.name('task')).sendKeys('testTask1'));
    expect(element(by.name('priority')).sendKeys('15'));
    expect(element(by.name('parentTask')).sendKeys('testparentTask1'));
    expect(element(by.name('startDate')).sendKeys('12/12/2018'));
    expect(element(by.name('endDate')).sendKeys('12/12/2018'));
    //verify the values in the input field
    expect(element(by.name('task')).getAttribute("value")).toBe('testTask1');
    expect(element(by.name('priority')).getAttribute("value")).toBe('15');
    expect(element(by.name('parentTask')).getAttribute("value")).toBe('testparentTask1');
    expect(element(by.name('startDate')).getAttribute("value")).toBe('2018-12-12');
    expect(element(by.name('endDate')).getAttribute("value")).toBe('2018-12-12');
    //click on add button
    expect(element(by.cssContainingText('app-add-task button','Add Task')).click);
    //click on reset button
    expect(element(by.cssContainingText('app-add-task button','Reset')).click);
  });

  it('should display view task page and display its fields and button behaviors', () => {
    //Navigate first to add task page
    page.navigateTo();
    //Navigate to view task page
    expect(page.getViewTaskRouterLink().getText()).toEqual('View Task');
    page.getViewTaskRouterLink().click();
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 300000;
    //check the task list table 
    expect(element(by.cssContainingText('app-view-task th','Task')).getText()).toEqual('Task');
    expect(element(by.cssContainingText('app-view-task th','Parent')).getText()).toEqual('Parent');
    expect(element(by.cssContainingText('app-view-task th','Priority')).getText()).toEqual('Priority');
    expect(element(by.cssContainingText('app-view-task th','Start')).getText()).toEqual('Start');
    expect(element(by.cssContainingText('app-view-task th','End')).getText()).toEqual('End');
    //check the search input fields in view task page
    expect(element(by.cssContainingText('app-view-task label','Task')).getText()).toEqual('Task');
    expect(element(by.cssContainingText('app-view-task label','Priority From')).getText()).toEqual('Priority From');
    expect(element(by.cssContainingText('app-view-task label','Priority To')).getText()).toEqual('Priority To');
    expect(element(by.cssContainingText('app-view-task label','Parent Task')).getText()).toEqual('Parent Task');
    expect(element(by.cssContainingText('app-view-task label','Start Date')).getText()).toEqual('Start Date');
    expect(element(by.cssContainingText('app-view-task label','End Date')).getText()).toEqual('End Date');
    //check if end task and edit buttons are available
    expect(element(by.id("0")).getText()).toEqual('End Task');
    expect(element(by.id("edit0")).getText()).toEqual('Edit');
    //edit the row
    expect(element(by.id("edit1")).click());
    // check the update field names after clicking the edit button
    expect(element(by.cssContainingText('app-view-task label','Task')).getText()).toEqual('Task');
    expect(element(by.cssContainingText('app-view-task label','Priority')).getText()).toEqual('Priority');
    expect(element(by.cssContainingText('app-view-task label','Parent Task')).getText()).toEqual('Parent Task');
    expect(element(by.cssContainingText('app-view-task label','Start Date')).getText()).toEqual('Start Date');
    expect(element(by.cssContainingText('app-view-task label','End Date')).getText()).toEqual('End Date');
    //Check the values for update
    expect(element(by.name('updateTask')).getAttribute("value")).toBe('task1');
    expect(element(by.name('updatePriority')).getAttribute("value")).toBe('11');
    expect(element(by.name('updateParentTask')).getAttribute("value")).toBe('parentTask1');
    expect(element(by.name('updateStartDate')).getAttribute("value")).toBe('2018-08-01');
    expect(element(by.name('updateEndDate')).getAttribute("value")).toBe('2018-08-01');
    //check the end task button functionality
    expect(element(by.id("0")).click());
    expect(element(by.id("0")).isEnabled()).toBe(false);
    expect(element(by.id("edit0")).isEnabled()).toBe(false);
  });

});
