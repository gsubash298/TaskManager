import { Component, OnInit } from '@angular/core';
import {Task} from '../task';
import {TaskService} from '../shared_service/task.service';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.scss']
})
export class AddTaskComponent implements OnInit {
  private task:Task;
  private taskError:Task;
  private isCreated:boolean=false;
  private taskExist:boolean=false;
  private errorMessage:String;

  constructor(private taskService: TaskService) { }

  ngOnInit() {
    this.task = new Task();
  }

  resetForm(){
    this.task.task='';
    this.task.priority=null;
    this.task.parentTask='';
    this.task.startDate='';
    this.task.endDate='';
  }

  addTask(){
    console.log(this.task.task);
    console.log(this.task.parentTask);
    console.log(this.task.priority);
    console.log(this.task.startDate);
    console.log(this.task.endDate);
    this.taskService.addTask(this.task).subscribe(task=>{
      console.log(task);
      this.isCreated=true;
      this.taskExist=false;
    },
  error=>{
    this.taskError=error.error;
    this.isCreated=false;
    this.errorMessage=error.error.description;
    if(error.error.code==409){
      this.isCreated=false;
      this.taskExist=true;
    }
    console.log(error);
  })
  }
}
