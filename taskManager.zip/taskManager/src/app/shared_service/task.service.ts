import { Injectable } from '@angular/core';
import { Task } from '../task';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  constructor(private httpClient: HttpClient) { }
  private baseUrl = "http://192.168.99.100:8080/taskmanagerFSD/taskManager";
  private headers = new Headers({'Content-Type': 'application/json'}); 
  private tasks:Task[];

  private httpOptions = {headers: new HttpHeaders({
    'Content-Type':  'application/json',
    "Authorization": "Basic " + btoa("taskMgr:taskMgr123")
  })};

  addTask(task:Task) {
    console.log(task);            
    return this.httpClient.post(this.baseUrl, JSON.stringify(task), this.httpOptions);
  }

  getTaskList() {   
    console.log("In the getTaskList");
    return this.httpClient.get<Task[]>(this.baseUrl);
  }

  deleteTask(taskId: Number) {
    return this.httpClient.delete(`${this.baseUrl+'/taskId'}?taskId=${taskId}`,this.httpOptions);
  }

  updateTask(task:Task) {
    console.log(task);            
    return this.httpClient.put(this.baseUrl, JSON.stringify(task),this.httpOptions);
  }

}
