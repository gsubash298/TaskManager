import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { TaskService } from './shared_service/task.service';
import { HttpModule } from '@angular/http';
import { DatePipe } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddTaskComponent } from './add-task/add-task.component';
import { ViewTaskComponent } from './view-task/view-task.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ViewTaskFilter } from './view-task/view-task-filter';

@NgModule({
  declarations: [
    AppComponent,
    AddTaskComponent,
    ViewTaskComponent,
    NavbarComponent,
    ViewTaskFilter
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule.forRoot(),
    FormsModule,
    HttpModule,    
    HttpClientModule
  ],
  providers: [TaskService, DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
