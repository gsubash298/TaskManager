import { Component, OnInit } from '@angular/core';
import {NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';
import {Task} from '../task';
import {TaskService} from '../shared_service/task.service';
import {Router} from '@angular/router';
import {DatePipe} from '@angular/common';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.scss']
})
export class AddTaskComponent implements OnInit {
  private task:Task;

  constructor(private taskService: TaskService, router: Router, private datePipe: DatePipe) { }

  ngOnInit() {
    this.task = new Task();
  }

  resetForm(){
    this.task.task='';
    this.task.priority=null;
    this.task.parentTask='';
    this.task.startDate='';
    this.task.endDate='';
  }

  addTask(){
    console.log(this.task.task);
    console.log(this.task.parentTask);
    console.log(this.task.priority);
    console.log(this.task.startDate);
    console.log(this.task.endDate);
    //this.task.startDate = this.task.startDate.;
    //this.task.startDate = this.datePipe.transform(this.task.startDate, 'yyyy-mm-dd');
    //this.task.endDate = this.datePipe.transform(this.task.endDate, 'yyyy-mm-dd');
    //this.task.startDate = JSON.stringify(this.task.startDate);
    //this.task.endDate = JSON.stringify(this.task.endDate);
    //console.log(this.task.startDate);
    //console.log(this.task.endDate);
    this.taskService.addTask(this.task).subscribe((task)=>{
      console.log(task);
    })
  }



}
