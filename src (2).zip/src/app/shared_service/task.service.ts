import { Injectable } from '@angular/core';
import { Task } from '../task';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  constructor(private http:Http, private httpClient: HttpClient) { }
  private baseUrl = "http://localhost:8080/taskmanagerFSD/taskManager";
  private headers = new Headers({'Content-Type': 'application/json'}); 
  private options = new RequestOptions ({headers: this.headers});
  private tasks:Task[];

  addTask(task:Task) {
    console.log(task);            
    return this.http.post(this.baseUrl, JSON.stringify(task), this.options);
    //.pipe(map((res: Response) => res.json()))
    //.pipe(catchError(this.error));
  }

  getTaskList() {   
    console.log("In the getTaskList");
    return this.httpClient.get(this.baseUrl);
    //.subscribe(
      //res=>console.log(res.json()));      
    //.pipe(map((res: Response) => res.json()))
    //.pipe(catchError(this.error));
  }

  deleteTask(taskId: Number) {
    return this.http.delete(`${this.baseUrl+'/taskId'}?taskId=${taskId}`, this.options);
  }

  updateTask(task:Task) {
    console.log(task);      
    //This call will have the taskId and the parentTaskId for update      
    return this.http.put(this.baseUrl, JSON.stringify(task), this.options);
  }
  //error(error: Response) {
    //return Observable.throw(error||"Error from service");
  //}

}
