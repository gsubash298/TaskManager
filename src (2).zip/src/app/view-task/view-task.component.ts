import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import {Task} from '../task';
import {TaskService} from '../shared_service/task.service';
import { DISABLED } from '@angular/forms/src/model';

@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.scss']
})
export class ViewTaskComponent implements OnInit {
  private task:Task;
  private tasks:Task[];
  private show:boolean=false;
  //private endTask:boolean=false;
  //private deletedTask:String;
  private i:number;

  constructor(private taskService: TaskService) { }

  ngOnInit() {    
    this.getTaskList();
  }

  getTaskList() {
    this.taskService.getTaskList().subscribe((res : Task[])=>{
      console.log(res);
      this.tasks = res;
      console.log("list of tasks" + this.tasks);
    });
  }
  
  deleteTask(task,i) {
    this.taskService.deleteTask(task.taskId).subscribe((task)=>{
      console.log(task);
    })
    //this.task.taskId = task.taskId;
    //this.endTask = true;  
    var editId = 'edit'+i;  
    (<HTMLInputElement> document.getElementById(i)).disabled = true;
    (<HTMLInputElement> document.getElementById(editId)).disabled = true;
    //console.log("fieldElement "+ (<HTMLInputElement>document.getElementById("'end'+i")));
    //console.log("value of i "+i);
    //fieldElement.disabled; 
  }

  editTask(task) {
    this.show=true;
    this.task=task;
  }
  updateTask(task:Task) {
    this.taskService.updateTask(this.task).subscribe((task)=>{
      console.log(task);
    })
    this.getTaskList();
  }

  enableDisable(task:Task){
    if (this.task.taskId ==  task.taskId)
      return true;
    else
      return false;
  }
}
