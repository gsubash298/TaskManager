import {Pipe, PipeTransform } from '@angular/core';
import { Task } from '../task';
@Pipe({
    name: 'taskSearchFilter'
})
export class ViewTaskFilter implements PipeTransform {
    transform(tasks: Task[], taskSearch: string, parentSearch: string, priorityFrom: Number, priorityTo: Number, startDateSearch: string, endDateSearch: string){
        if (tasks && tasks.length){
            return tasks.filter(task =>{
                if (taskSearch && task.task.toLowerCase().indexOf(taskSearch.toLowerCase()) === -1){
                    return false;
                }
                if (parentSearch && task.parentTask.toLowerCase().indexOf(parentSearch.toLowerCase()) === -1){
                    return false;
                }
                if (priorityFrom && task.priority<priorityFrom){
                    return false;
                }
                if (priorityTo && task.priority>priorityTo){
                    return false;
                }
                //console.log(task.startDate);
                //console.log(startDateSearch);
                //console.log(task.startDate!=startDateSearch);
                if (startDateSearch && task.startDate!=startDateSearch){
                    return false;
                }
                if (endDateSearch && task.endDate!=endDateSearch){
                    return false;
                }

                return true;
           })
        }
        else{
            return tasks;
        }
    }
}
